//=============================================================================
// de1_soc_d8m_lb_rtl.v  –  Top-level module (Lab 5 updated)
//
// Changes from original template:
//   • RGB_Process instantiation updated with new ports:
//       clk, reset_n, SW, KEY
//   • Everything else is unchanged.
//=============================================================================

module DE1_SOC_D8M_LB_RTL (

   //--- 50 MHz clock from DE1-SoC board
   input          CLOCK_50,

   //--- 10 Switches
   input    [9:0] SW,

   //--- 4 Push buttons
   input    [3:0] KEY,

   //--- 10 LEDs
   output   [9:0] LEDR,

   //--- 6 7-segment hexadecimal displays
   output   [7:0] HEX0,
   output   [7:0] HEX1,
   output   [7:0] HEX2,
   output   [7:0] HEX3,
   output   [7:0] HEX4,
   output   [7:0] HEX5,

   //--- VGA
   output         VGA_BLANK_N,
   output  [7:0]  VGA_B,
   output         VGA_CLK,
   output  [7:0]  VGA_G,
   output reg     VGA_HS,
   output  [7:0]  VGA_R,
   output         VGA_SYNC_N,
   output reg     VGA_VS,

   //--- GPIO_1 – D8M-GPIO camera
   inout          CAMERA_I2C_SCL,
   inout          CAMERA_I2C_SDA,
   output         CAMERA_PWDN_n,
   output         MIPI_CS_n,
   inout          MIPI_I2C_SCL,
   inout          MIPI_I2C_SDA,
   output         MIPI_MCLK,
   input          MIPI_PIXEL_CLK,
   input   [9:0]  MIPI_PIXEL_D,
   input          MIPI_PIXEL_HS,
   input          MIPI_PIXEL_VS,
   output         MIPI_REFCLK,
   output         MIPI_RESET_n
);

//=============================================================================
// reg / wire declarations
//=============================================================================
   wire           orequest;
   wire    [7:0]  raw_VGA_R;
   wire    [7:0]  raw_VGA_G;
   wire    [7:0]  raw_VGA_B;
   wire           RESET_N;
   wire   [12:0]  x_count, col;
   wire   [12:0]  y_count, row;
   wire           CAMERA_MIPI_RELAESE;
   wire           MIPI_BRIDGE_RELEASE;

   wire           LUT_MIPI_PIXEL_HS;
   wire           LUT_MIPI_PIXEL_VS;
   wire    [9:0]  LUT_MIPI_PIXEL_D;

//=============================================================================
// Signal assignments
//=============================================================================

assign LUT_MIPI_PIXEL_HS = MIPI_PIXEL_HS;
assign LUT_MIPI_PIXEL_VS = MIPI_PIXEL_VS;
assign LUT_MIPI_PIXEL_D  = MIPI_PIXEL_D;

// SW[0] = reset: SW[0] HIGH → RESET_N LOW (active-low reset throughout)
assign RESET_N       = ~SW[0];
assign MIPI_RESET_n  = RESET_N;
assign CAMERA_PWDN_n = RESET_N;
assign MIPI_CS_n     = 1'b0;

// LED / HEX demos (unchanged from template)
assign LEDR[0]  = SW[9];
assign HEX0[0]  = KEY[3];

// Unused HEX segments driven to off (active-low segments)
assign HEX0[7:1] = 7'h7F;
assign HEX1      = 8'hFF;
assign HEX2      = 8'hFF;
assign HEX3      = 8'hFF;
assign HEX4      = 8'hFF;
assign HEX5      = 8'hFF;
assign LEDR[9:1] = 9'd0;

//=============================================================================
// Module instantiations
//=============================================================================

//--- MIPI Bridge + Camera I2C config
MIPI_BRIDGE_CAMERA_Config cfin (
   .RESET_N            ( RESET_N            ),
   .CLK_50             ( CLOCK_50           ),
   .MIPI_I2C_SCL       ( MIPI_I2C_SCL       ),
   .MIPI_I2C_SDA       ( MIPI_I2C_SDA       ),
   .MIPI_I2C_RELEASE   ( MIPI_BRIDGE_RELEASE),
   .CAMERA_I2C_SCL     ( CAMERA_I2C_SCL     ),
   .CAMERA_I2C_SDA     ( CAMERA_I2C_SDA     ),
   .CAMERA_I2C_RELAESE ( CAMERA_MIPI_RELAESE)
);

//--- Video PLL  (50 MHz → 20 MHz for MIPI ref clock)
video_pll MIPI_clk (
   .refclk   ( CLOCK_50    ),
   .rst      ( 1'b0        ),
   .outclk_0 ( MIPI_REFCLK )
);

//--- D8M raw-to-RGB decoder
D8M_SET ccd (
   .RESET_SYS_N ( RESET_N            ),
   .CLOCK_50    ( CLOCK_50           ),
   .CCD_DATA    ( LUT_MIPI_PIXEL_D   ),
   .CCD_FVAL    ( LUT_MIPI_PIXEL_VS  ),
   .CCD_LVAL    ( LUT_MIPI_PIXEL_HS  ),
   .CCD_PIXCLK  ( MIPI_PIXEL_CLK     ),
   .READ_EN     ( orequest           ),
   .VGA_HS      ( VGA_HS             ),
   .VGA_VS      ( VGA_VS             ),
   .X_Cont      ( x_count            ),
   .Y_Cont      ( y_count            ),
   .sCCD_R      ( raw_VGA_R          ),
   .sCCD_G      ( raw_VGA_G          ),
   .sCCD_B      ( raw_VGA_B          )
);

//--- Video processing (Lab 5)
//    New ports added: clk, reset_n, SW, KEY
RGB_Process p1 (
   .clk       ( MIPI_PIXEL_CLK ),   // 25 MHz pixel clock
   .reset_n   ( RESET_N        ),   // active-low reset from SW[0]
   .raw_VGA_R ( raw_VGA_R      ),
   .raw_VGA_G ( raw_VGA_G      ),
   .raw_VGA_B ( raw_VGA_B      ),
   .row       ( row            ),
   .col       ( col            ),
   .SW        ( SW             ),
   .KEY       ( KEY            ),
   .o_VGA_R   ( VGA_R          ),
   .o_VGA_G   ( VGA_G          ),
   .o_VGA_B   ( VGA_B          )
);

//=============================================================================
// VGA timing signals  (unchanged from template)
//=============================================================================

assign VGA_CLK    = MIPI_PIXEL_CLK;
assign VGA_SYNC_N = 1'b0;

assign orequest = ((x_count > 13'd0160 && x_count < 13'd0800) &&
                   (y_count > 13'd0045 && y_count < 13'd0525));

assign VGA_BLANK_N = ~((x_count < 13'd0160) || (y_count < 13'd0045));

always @(*) begin
   VGA_HS = ((x_count >= 13'd0002) && (x_count <= 13'd0097)) ? 1'b0 : 1'b1;
   VGA_VS = ((y_count >= 13'd0013) && (y_count <= 13'd0014)) ? 1'b0 : 1'b1;
end

assign col = x_count - 13'd0164;
assign row = y_count - 13'd0047;

endmodule
