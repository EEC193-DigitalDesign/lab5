// =============================================================================
// RGB_Process.v
// EEC 181A Lab 5 – Real-Time Video Processing
//
// Part 1: RGB Color Filters      (SW[2:1]=Red, SW[4:3]=Green, SW[6:5]=Blue)
// Part 2: Cursors                (SW[7]=select cursor A/B, KEY[3:0]=move)
//           Cursor A: 3x3 solid block
//           Cursor B: 10x10 hollow box (1-pixel border)
// Part 3: Grayscale              (SW[8]=enable grayscale)
//
// Switch Map Summary:
//   SW[0]   – system reset (active-HIGH, wired in top-level as RESET_N=~SW[0])
//   SW[2:1] – Red   intensity: 00=full  01=1/2  10=1/4  11=off
//   SW[4:3] – Green intensity: 00=full  01=1/2  10=1/4  11=off
//   SW[6:5] – Blue  intensity: 00=full  01=1/2  10=1/4  11=off
//   SW[7]   – cursor select: 0 = move cursor A,  1 = move cursor B
//   SW[8]   – grayscale enable (can stack with colour filters)
//   SW[9]   – unused here (LED demo in top-level)
//
// Key Map (active-LOW on DE1-SoC):
//   KEY[3] – move up
//   KEY[2] – move down
//   KEY[1] – move left
//   KEY[0] – move right
// =============================================================================

module RGB_Process (
    input         clk,       // 25 MHz pixel clock (MIPI_PIXEL_CLK)
    input         reset_n,   // active-low reset  (~SW[0] from top-level)

    input  [7:0]  raw_VGA_R,
    input  [7:0]  raw_VGA_G,
    input  [7:0]  raw_VGA_B,
    input  [12:0] row,       // 0–477
    input  [12:0] col,       // 0–616

    input  [9:0]  SW,
    input  [3:0]  KEY,       // active-low push buttons

    output reg [7:0] o_VGA_R,
    output reg [7:0] o_VGA_G,
    output reg [7:0] o_VGA_B
);

// =============================================================================
// PART 1 – RGB Colour Filters
// =============================================================================

    reg [7:0] filt_R, filt_G, filt_B;

    always @(*) begin
        // --- Red ---
        case (SW[2:1])
            2'b00: filt_R = raw_VGA_R;
            2'b01: filt_R = raw_VGA_R >> 1;
            2'b10: filt_R = raw_VGA_R >> 2;
            2'b11: filt_R = 8'd0;
        endcase

        // --- Green ---
        case (SW[4:3])
            2'b00: filt_G = raw_VGA_G;
            2'b01: filt_G = raw_VGA_G >> 1;
            2'b10: filt_G = raw_VGA_G >> 2;
            2'b11: filt_G = 8'd0;
        endcase

        // --- Blue ---
        case (SW[6:5])
            2'b00: filt_B = raw_VGA_B;
            2'b01: filt_B = raw_VGA_B >> 1;
            2'b10: filt_B = raw_VGA_B >> 2;
            2'b11: filt_B = 8'd0;
        endcase
    end

// =============================================================================
// PART 3 – Grayscale Conversion  (applied after colour filter, SW[8])
//
// Luminance = 0.2126*R + 0.7152*G + 0.0722*B
//
// 8-bit unsigned fractional coefficients  (multiply × 256, round):
//   0.2126 × 256 = 54.43  →  54  (0x36)
//   0.7152 × 256 = 183.09 → 183  (0xB7)
//   0.0722 × 256 = 18.48  →  18  (0x12)
//   Total = 255 ✓
//
// Each 8×8 multiply produces a 16-bit product.
// Sum the three products (18 bits max), then take bits [15:8] as the
// 8-bit luminance (equivalent to dividing by 256).
// =============================================================================

    wire [15:0] lum_R_prod = filt_R * 8'd54;
    wire [15:0] lum_G_prod = filt_G * 8'd183;
    wire [15:0] lum_B_prod = filt_B * 8'd18;

    wire [17:0] lum_sum = {2'b0, lum_R_prod}
                        + {2'b0, lum_G_prod}
                        + {2'b0, lum_B_prod};

    wire [7:0] luminance = lum_sum[15:8];

    // Grayscale mux (SW[8] = 1 → grayscale; works simultaneously with filters)
    wire [7:0] proc_R = SW[8] ? luminance : filt_R;
    wire [7:0] proc_G = SW[8] ? luminance : filt_G;
    wire [7:0] proc_B = SW[8] ? luminance : filt_B;

// =============================================================================
// PART 2 – Cursor Movement
//
// Slow-clock divider:
//   25 MHz / 2^18 = ~95 Hz  → each button press moves ~1 pixel per 10 ms
//   Easy to control precisely.
// =============================================================================

    reg [17:0] slow_cnt;
    wire       slow_en = (slow_cnt == 18'd0);   // 1-cycle enable pulse at ~95 Hz

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) slow_cnt <= 18'd0;
        else          slow_cnt <= slow_cnt + 1'b1;
    end

    // ---- Cursor A: 3×3 solid block ----------------------------------------
    // (ax, ay) = top-left corner.  Max: ax ≤ 614, ay ≤ 475
    reg [9:0] ax, ay;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            ax <= 10'd100; ay <= 10'd100;
        end else if (slow_en && SW[7] == 1'b0) begin
            if (!KEY[3] && ay > 10'd0)   ay <= ay - 1'd1;  // up
            if (!KEY[2] && ay < 10'd475) ay <= ay + 1'd1;  // down
            if (!KEY[1] && ax > 10'd0)   ax <= ax - 1'd1;  // left
            if (!KEY[0] && ax < 10'd614) ax <= ax + 1'd1;  // right
        end
    end

    // ---- Cursor B: 10×10 hollow box (1-pixel border) ----------------------
    // (bx, by) = top-left corner.  Max: bx ≤ 607, by ≤ 468
    reg [9:0] bx, by;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            bx <= 10'd300; by <= 10'd200;
        end else if (slow_en && SW[7] == 1'b1) begin
            if (!KEY[3] && by > 10'd0)   by <= by - 1'd1;  // up
            if (!KEY[2] && by < 10'd468) by <= by + 1'd1;  // down
            if (!KEY[1] && bx > 10'd0)   bx <= bx - 1'd1;  // left
            if (!KEY[0] && bx < 10'd607) bx <= bx + 1'd1;  // right
        end
    end

    // ---- Pixel hit-test (combinational) ------------------------------------
    // Widen cursor registers to 13-bit for safe comparison with col/row.
    wire [12:0] ax13 = {3'b0, ax};
    wire [12:0] ay13 = {3'b0, ay};
    wire [12:0] bx13 = {3'b0, bx};
    wire [12:0] by13 = {3'b0, by};

    // Cursor A: any pixel inside the 3×3 block
    wire hit_A = (col >= ax13)          && (col < ax13 + 13'd3) &&
                 (row >= ay13)          && (row < ay13 + 13'd3);

    // Cursor B: on the 1-pixel border of a 10×10 box
    wire in_outer_B = (col >= bx13)          && (col < bx13 + 13'd10) &&
                      (row >= by13)          && (row < by13 + 13'd10);
    wire in_inner_B = (col >= bx13 + 13'd1) && (col < bx13 + 13'd9)  &&
                      (row >= by13 + 13'd1) && (row < by13 + 13'd9);
    wire hit_B = in_outer_B && !in_inner_B;

    wire cursor_hit = hit_A | hit_B;   // cyan: R=0, G=255, B=255

// =============================================================================
// Output mux  (priority: corner markers > cursor > processed video > black)
// =============================================================================

    always @(*) begin
        // -- Corner markers (always visible for reference) --
        if (row < 13'd5 && col < 13'd5) begin
            // top-left: solid red
            o_VGA_R = 8'hFF; o_VGA_G = 8'h00; o_VGA_B = 8'h00;
        end
        else if (row < 13'd5 && col >= 13'd612 && col < 13'd617) begin
            // top-right: solid green
            o_VGA_R = 8'h00; o_VGA_G = 8'hFF; o_VGA_B = 8'h00;
        end
        else if (row >= 13'd473 && row < 13'd478 && col < 13'd5) begin
            // bottom-left: solid blue
            o_VGA_R = 8'h00; o_VGA_G = 8'h00; o_VGA_B = 8'hFF;
        end
        // -- Cursor pixels: cyan (green + blue) --
        else if (cursor_hit && row < 13'd478 && col < 13'd617) begin
            o_VGA_R = 8'h00; o_VGA_G = 8'hFF; o_VGA_B = 8'hFF;
        end
        // -- Normal processed video --
        else if (row < 13'd478 && col < 13'd617) begin
            o_VGA_R = proc_R;
            o_VGA_G = proc_G;
            o_VGA_B = proc_B;
        end
        // -- Outside active camera area: black --
        else begin
            o_VGA_R = 8'h00; o_VGA_G = 8'h00; o_VGA_B = 8'h00;
        end
    end

endmodule
